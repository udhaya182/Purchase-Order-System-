$(document).ready(function () {
    // Load Parts
    $('#load-parts').click(function () {
        const tableContainer = $('#parts-section-container');
        const tableBody = $('#parts-table tbody');

        // Check if the table is hidden
        if (tableContainer.hasClass('d-none')) {
            // Change button color to indicate it's active
            $(this).addClass('btn-success').removeClass('btn-primary');

            $.ajax({
                url: '/api/parts802',
                method: 'GET',
                success: function (data) {
                    tableBody.empty(); // Clear the table before populating
                    data.forEach(function (part) {
                        tableBody.append(`
                            <tr>
                                <td>${part[0]}</td>
                                <td>${part[1]}</td>
                                <td>${part[2]}</td>
                            </tr>
                        `);
                    });
                    tableContainer.removeClass('d-none'); // Show parts table and heading
                },
                error: function () {
                    alert('Failed to load parts.');
                }
            });
        } else {
            // If the table is already visible, just clear it and hide it
            tableContainer.addClass('d-none'); // Hide the table
            $(this).removeClass('btn-success').addClass('btn-primary'); // Reset button color
            tableBody.empty(); // Clear the table data when hiding
        }
    });

    // Load Purchase Orders
    $('#load-pos').click(function () {
        const tableContainer = $('#pos-section-container');
        const tableBody = $('#pos-table tbody');

        // Check if the table is hidden
        if (tableContainer.hasClass('d-none')) {
            // Change button color to indicate it's active
            $(this).addClass('btn-success').removeClass('btn-primary');

            $.ajax({
                url: '/api/pos802',
                method: 'GET',
                success: function (data) {
                    tableBody.empty(); // Clear the table before populating
                    data.forEach(function (po) {
                        tableBody.append(`
                            <tr>
                                <td>${po[0]}</td>
                                <td>${po[1]}</td>
                            </tr>
                        `);
                    });
                    tableContainer.removeClass('d-none'); // Show purchase orders table and heading
                },
                error: function () {
                    alert('Failed to load purchase orders.');
                }
            });
        } else {
            // If the table is already visible, just clear it and hide it
            tableContainer.addClass('d-none'); // Hide the table
            $(this).removeClass('btn-success').addClass('btn-primary'); // Reset button color
            tableBody.empty(); // Clear the table data when hiding
        }
    });

    // Load specific PO info
    $('#load-po-info').click(function () {
        const poNo = $('#po-number-input').val();
        $.ajax({
            url: `/api/pos802/${poNo}`,
            method: 'GET',
            success: function (data) {
                $('#po-info').html(`
                    <h5>PO Number: ${data.poNo}</h5>
                    <p>Client ID: ${data.clientId}</p>
                    <p>Date: ${data.PoDate}</p>
                    <h6>Order Lines:</h6>
                    <ul>
                        ${data.lines.map(line => `<li>Part No: ${line[0]}, Qty: ${line[1]}, Price: ${line[2]}</li>`).join('')}
                    </ul>
                `);
            },
            error: function () {
                $('#po-info').html('<p class="text-danger">PO number does not exist.</p>');
            }
        });
    });

    // Submit Purchase Order
    $('#submit-po').click(function () {
        const clientId = $('#client-id-input').val();
        const partNo = $('#part-no-input').val();
        const qty = $('#qty-input').val();
        const price = $('#price-input').val();

        // Check if all required fields are filled
        if (!clientId || !partNo || !qty || !price) {
            $('#submit-result').html('<p class="text-danger">Please fill in all fields.</p>');
            return; // Early return if fields are missing
        }

        $.ajax({
            url: '/api/pos802',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                clientId: clientId,
                lines: [
                    { partNo: parseInt(partNo), qty: parseInt(qty), price: parseFloat(price) }
                ]
            }),
            success: function (data) {
                // Display success message from the server response
                $('#submit-result').html(`<p class="text-success">${data.result}</p>`);
            },
            error: function (xhr) {
                // Display error message from the server response
                $('#submit-result').html(`<p class="text-danger">${xhr.responseJSON.result}</p>`);
            }
        });
    });
});
