from flask import Flask, request, jsonify, render_template
import mysql.connector
from dotenv import load_dotenv
import os

app = Flask(__name__)

# Load environment variables from .env
load_dotenv()

# Accessing the environment variables
db_host = os.getenv('DB_HOST')
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')
db_name = os.getenv('DB_NAME')

# Database connection settings
db_config = {
    'user': db_user,
    'password': db_password,
    'host': db_host,
    'database': db_name
}

# Establish connection to the database
def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        print("Database connection successful.")
        return conn
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

# List parts for sale
@app.route('/api/parts802', methods=['GET'])
def listParts802():
    conn = get_db_connection()
    if conn is None:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor()
    cursor.execute("SELECT partName, QoH, currentPrice FROM Parts_802")
    parts = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(parts)

# List purchase orders
@app.route('/api/pos802', methods=['GET'])
def listPos802():
    conn = get_db_connection()
    if conn is None:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor()
    cursor.execute("SELECT PoNo_802, PoDate FROM PurchaseOrders_802")
    pos = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(pos)

# List information about a specific PO
@app.route('/api/pos802/<int:poNo>', methods=['GET'])
def listPOinfo802(poNo):
    conn = get_db_connection()
    if conn is None:
        return jsonify({"error": "Database connection failed"}), 500

    cursor = conn.cursor()
    cursor.execute("SELECT * FROM PurchaseOrders_802 WHERE PoNo_802 = %s", (poNo,))
    po_info = cursor.fetchone()

    if not po_info:
        cursor.close()
        conn.close()
        return jsonify({"error": "PO number does not exist"}), 404

    cursor.execute("SELECT OrderLines_partNo, orderQuantity, priceAtOrder FROM OrderLines_802 WHERE OrderLines_PoNo = %s", (poNo,))
    po_lines = cursor.fetchall()

    cursor.close()
    conn.close()

    return jsonify({"poNo": po_info[0], "clientId": po_info[1], "PoDate": po_info[2], "lines": po_lines})

# Submit purchase order
@app.route('/api/pos802', methods=['POST'])
def submitPO802():
    data = request.json
    client_id = data.get('clientId')
    lines = data.get('lines')

    # Validation: Check if client ID and lines are provided
    if not client_id or not lines:
        return jsonify({"result": "Client ID and order lines are required"}), 400

    conn = get_db_connection()
    if conn is None:
        return jsonify({"result": "Database connection failed"}), 500

    cursor = conn.cursor()

    try:
        # 1. Check if client ID is valid
        cursor.execute("SELECT COUNT(*) FROM Clients_802 WHERE clientId_802 = %s", (client_id,))
        if cursor.fetchone()[0] == 0:
            return jsonify({"result": "Invalid client ID"}), 400

        # 2. Check part numbers and stock availability
        total_value = 0
        for line in lines:
            part_no = line.get('partNo')
            qty = line.get('qty')

            cursor.execute("SELECT QoH FROM Parts_802 WHERE partNo_802 = %s", (part_no,))
            part = cursor.fetchone()
            if part is None:
                return jsonify({"result": f"Invalid part number: {part_no}"}), 400

            if part[0] < qty:
                return jsonify({"result": f"Not enough stock for part number: {part_no}"}), 400
            
            # Calculate total value for the order
            price = line.get('price', 0)  # Assuming price is passed in the line
            total_value += qty * price

        # Validation passed - Assign a PO number and insert PO into DB
        cursor.execute("INSERT INTO PurchaseOrders_802 (PurchaseOrders_clientId, PoDate, PoStatus) VALUES (%s, NOW(), 'Pending')", (client_id,))
        po_no = cursor.lastrowid

        # Insert order lines into the DB
        for line in lines:
            part_no = line.get('partNo')
            qty = line.get('qty')
            price = line.get('price')

            # Fetch the next line number for this purchase order
            cursor.execute("""
                SELECT COALESCE(MAX(lineNo_802), 0) + 1 AS nextLineNo
                FROM OrderLines_802
                WHERE OrderLines_PoNo = %s;
            """, (po_no,))
            next_line_no = cursor.fetchone()[0]

            cursor.execute("""
                INSERT INTO OrderLines_802 (OrderLines_PoNo, lineNo_802, OrderLines_partNo, orderQuantity, priceAtOrder)
                VALUES (%s, %s, %s, %s, %s)
            """, (po_no, next_line_no, part_no, qty, price))

            # Reduce the stock for each part
            cursor.execute("UPDATE Parts_802 SET QoH = QoH - %s WHERE partNo_802 = %s", (qty, part_no))

        # Commit the changes
        conn.commit()
        
        # Total value is added to client's money owed via trigger, no need to update here
        result_message = f"Purchase order submitted successfully with PO number: {po_no}"
        return jsonify({"result": result_message}), 201

    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({"result": f"Failed to submit PO: {err}"}), 500

    finally:
        cursor.close()
        conn.close()

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
